#include "functions.h"
/*

******************************************************************************************
*	Name: Justin Harper																	 *
*	WSU ID: 10696738                                                                     *
*	Programing Assignment 3, version 1.0												 *
*																						 *
*	Description:																		 *
*	This program will  processes numbers, corresponding to student records				 *
*	read in from a file, and writes the required results to an output file				 *
*	This program has some input validation and divide by 0								 *
*	validation, still be sure input is clean!											 *
*																						 *
******************************************************************************************

*/


int main(void)
{
	startHere();
	return 0;

}