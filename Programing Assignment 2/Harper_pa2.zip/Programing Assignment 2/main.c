/*

******************************************************************************************
*	Name: Justin Harper																	 *
*	WSU ID: 10696738                                                                     *
*	Programing Assignment 2, version 2.0												 *
*																						 *
*	Description:																		 *
*	This program will prompt the user for inputs to some equations and evaluate			 *
*	the equations based on the inputs.													 *
*	This program has some input validation and divide by 0								 *
*	validation, still be sure input is clean!											 *
*																						 *
******************************************************************************************

*/
#include "equations.h"

//Function definitions:
int main(void)
{
		
	printf("\t\t  Hello!\nThis program will solve some equations for you\n\n\t\t  Lets Begin\n");

	startHere();
	
	return 0;
}






//all rights reserved � Justin Harper 2013