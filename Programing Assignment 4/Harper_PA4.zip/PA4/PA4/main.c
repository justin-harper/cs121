/*

******************************************************************************************
*	Name: Justin Harper																	 *
*	WSU ID: 10696738                                                                     *
*	Programing Assignment 4, version 0.1												 *
*																						 *
*	Description:																		 *
*	This program will let you play a game of Yahtzee									 *
*																						 *
******************************************************************************************

*/


#include "Yahtzee.h"


int main(void)
{

	startHere();
	return 0;
}