/*
	*	
	*		Justin Harper 
	*		PA6 - Battleship
	*		Version 0.1
	*
    */


#include "pa6.h"

int main (void)
{
	srand((unsigned) time(NULL)); //needed for random player start
	
	battleShip();

	return 0;
}