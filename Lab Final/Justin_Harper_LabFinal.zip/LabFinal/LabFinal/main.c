#include "labfinal.h"

int main (void)
{
		menu();
	

	return 0;
}