#include "pa8.h"



int main (void)
{

	//startHere();
	//part2();

	//part4();

	part5();

	return 0;
}