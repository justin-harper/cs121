#include "pa7.h"

int main (void)
{
	
	
	srand ((unsigned)time(NULL));
	

	
	mathProgram();

	return 0;
}